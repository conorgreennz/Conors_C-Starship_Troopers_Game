﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DiveBomb
{

    public class Ship
    {
        public int X;
        public int Y;
        public int Angle;

        const int MOVE_RATE = 7;


        public void MoveLeft()
        {
            X -= MOVE_RATE;
        }
        public void MoveRight()
        {
            X += MOVE_RATE;
        }
        public void MoveUp()
        {
            Y -= MOVE_RATE;
        }
        public void MoveDown()
        {
            Y += MOVE_RATE;
        }
        public void RotateLeft()
        {
            Angle -= MOVE_RATE;
        }
        public void RotateRight()
        {
            Angle += MOVE_RATE;
        }
       

        // make sure the ship does not leave the borders of the game panels x axis 
        // if it does bounce it back in
        // make sure the ship does not leave the borders of the game panels Y axis 
        // if it does bounce it back in 
        }
    }

